"""ローカル開発用の設定。DB は SQLite(manage.py と同じフォルダの myappdb.sqlite3)。"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# 環境変数 DJANGO_SECRET_KEY があればそれを使う(AWS など本番用)。無ければ開発用の値を使う。
SECRET_KEY = os.environ.get('DJANGO_SECRET_KEY', 'local-dev-key-change-me-0123456789')

DEBUG = True

ALLOWED_HOSTS = ['127.0.0.1', 'localhost']

INSTALLED_APPS = [
    'django.contrib.staticfiles',
    'app',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'myappdb.sqlite3',
    }
}

# セッションは Cookie(署名付き)に保存する。セッション用のテーブルは不要なので migrate は不要。
SESSION_ENGINE = 'django.contrib.sessions.backends.signed_cookies'


LANGUAGE_CODE = 'ja'
TIME_ZONE = 'Asia/Tokyo'
USE_I18N = True
USE_TZ = True

STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
